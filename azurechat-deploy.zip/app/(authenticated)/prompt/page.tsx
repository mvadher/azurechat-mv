import { ChatSamplePromptPage } from "@/features/prompt-page/prompt-page";

export default async function Home() {
  return <ChatSamplePromptPage />;
}
